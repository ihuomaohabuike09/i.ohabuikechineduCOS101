// Define a Laptop struct with brand and price fields
struct Laptop {
    brand: String,
    price: u32,
}

// Implement methods for the Laptop struct
impl Laptop {
    // A method that calculates the total cost for a given quantity purchased
    fn purchase_cost(&self, quantity: u32) -> u32 {
        self.price * quantity
    }
}

fn main() {
    // Initialize the laptop brands from Mr Ogbeifuna's consignment
    let hp = Laptop {
        brand: String::from("HP"),
        price: 650000,
    };

    let ibm = Laptop {
        brand: String::from("IBM"),
        price: 755000,
    };

    let toshiba = Laptop {
        brand: String::from("Toshiba"),
        price: 550000,
    };

    let dell = Laptop {
        brand: String::from("Dell"),
        price: 850000,
    };

    // A customer purchases 3 laptops from each brand
    let qty = 3;

    let hp_total = hp.purchase_cost(qty);
    let ibm_total = ibm.purchase_cost(qty);
    let toshiba_total = toshiba.purchase_cost(qty);
    let dell_total = dell.purchase_cost(qty);

    // Calculate one grand total across the four brands
    let grand_total = hp_total + ibm_total + toshiba_total + dell_total;

    // Print out the results cleanly
    println!("--- Alaba Electronics Purchase Summary ---");
    println!("Buying {} units of each brand:", qty);
    println!("{} Total: N{}", hp.brand, hp_total);
    println!("{} Total: N{}", ibm.brand, ibm_total);
    println!("{} Total: N{}", toshiba.brand, toshiba_total);
    println!("{} Total: N{}", dell.brand, dell_total);
    println!("----------------------------------------");
    println!("Grand Total Across All Brands: N{}", grand_total);
}
